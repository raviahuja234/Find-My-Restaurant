module.exports = {
    restaurantCategory: {
        takeout: 'TAKEOUT',
        dineout: 'DINEOUT',
    }
}
module.exports = {

    url: 'mongodb+srv://YashrajPawar:<password>@cluster0.mjamzjk.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'

}